
function App() {
  return (
      <div>
        <p>Hello World!</p>
      </div>
  );
}

export default App;
